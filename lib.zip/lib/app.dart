import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/shell/main_shell.dart';

class PairBloomApp extends StatelessWidget {
  const PairBloomApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PairBloom',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    darkTheme: AppTheme.dark,
    themeMode: ThemeMode.system,
    home: const MainShell(),
  );
}
