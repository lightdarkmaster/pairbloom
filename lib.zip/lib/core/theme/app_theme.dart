import 'package:flutter/material.dart';

class AppTheme {
  static const rose = Color(0xFFD85B83);
  static const blush = Color(0xFFFCE4EC);
  static const ink = Color(0xFF382631);

  static ThemeData get light => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: rose, brightness: Brightness.light),
    scaffoldBackgroundColor: const Color(0xFFFFF9FA),
    appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Color(0xFFFFF9FA), foregroundColor: ink),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFF2E5EA))),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFFFF5F7),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
    ),
  );

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: rose, brightness: Brightness.dark),
    scaffoldBackgroundColor: const Color(0xFF211820),
    cardTheme: CardThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
  );
}
