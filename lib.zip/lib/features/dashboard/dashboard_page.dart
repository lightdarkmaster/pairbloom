import 'package:flutter/material.dart';
import '../../core/database/app_database.dart';
import '../../core/theme/app_theme.dart';
import '../records/record_list_page.dart';
import '../../core/models/module_config.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map<String, int> counts = {};
  String partnerOne = 'You', partnerTwo = 'Your sweetheart';
  DateTime relationshipStart = DateTime.now();

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final db = AppDatabase.instance;
    final profile = (await db.getAll('couple_profiles')).first;
    final Map<String, int> next = {};
    for (final table in ['memories','love_notes','important_dates','bucket_list']) {
      next[table] = (await db.getAll(table)).length;
    }
    if (!mounted) return;
    setState(() {
      counts = next;
      partnerOne = profile['partner_one'] as String;
      partnerTwo = profile['partner_two'] as String;
      relationshipStart = DateTime.tryParse(profile['relationship_start'] as String? ?? '') ?? DateTime.now();
    });
  }

  @override
  Widget build(BuildContext context) {
    final days = DateTime.now().difference(DateTime(relationshipStart.year, relationshipStart.month, relationshipStart.day)).inDays;
    return Scaffold(
      appBar: AppBar(title: const Text('PairBloom', style: TextStyle(fontWeight: FontWeight.w900))),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            padding: const EdgeInsets.all(23),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFF7B6CA), Color(0xFFFCE4EC)]),
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('A LITTLE SPACE FOR TWO HEARTS', style: TextStyle(fontSize: 10, letterSpacing: 1.8, fontWeight: FontWeight.w900, color: AppTheme.ink)),
              const SizedBox(height: 13),
              Text('$partnerOne  ♥  $partnerTwo', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppTheme.ink)),
              const SizedBox(height: 6),
              Text('$days days together', style: const TextStyle(fontSize: 16, color: AppTheme.ink)),
              const SizedBox(height: 14),
              const Text('“The little things become the big memories.”', style: TextStyle(fontStyle: FontStyle.italic, color: AppTheme.ink)),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('Your little world', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.65,
            children: [
              _Stat('Memories', counts['memories'] ?? 0, Icons.photo_album_outlined),
              _Stat('Love notes', counts['love_notes'] ?? 0, Icons.mail_outline),
              _Stat('Special dates', counts['important_dates'] ?? 0, Icons.event_outlined),
              _Stat('Bucket list', counts['bucket_list'] ?? 0, Icons.checklist),
            ],
          ),
          const SizedBox(height: 20),
          const Text('Made for your everyday moments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (var i = 1; i < modules.length; i++)
            Card(child: ListTile(
              leading: CircleAvatar(backgroundColor: AppTheme.blush, child: Icon(modules[i].icon, color: AppTheme.rose)),
              title: Text(modules[i].title, style: const TextStyle(fontWeight: FontWeight.w700)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RecordListPage(configIndex: i))).then((_) => load()),
            )),
        ]),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, this.icon);
  final String label; final int value; final IconData icon;
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(15),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Icon(icon, color: AppTheme.rose), Text('$value', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      Text(label, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w600)),
    ]),
  ));
}
