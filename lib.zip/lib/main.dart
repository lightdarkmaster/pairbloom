import 'package:flutter/material.dart';
import 'app.dart';
import 'core/database/app_database.dart';
import 'core/services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  await NotificationService.instance.initialize();
  runApp(const PairBloomApp());
}
